import os
import re
from pathlib import Path
from typing import List, Dict, Any

from dotenv import load_dotenv
from google import genai
from pinecone import Pinecone
from sentence_transformers import SentenceTransformer


# =========================
# 기본 설정
# =========================

BASE_DIR = Path(__file__).resolve().parent
ENV_PATH = BASE_DIR / ".env"

load_dotenv(ENV_PATH)

# Gemini
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
ROUTER_MODEL = os.getenv("ROUTER_MODEL", "gemini-2.5-flash")

# Pinecone
PINECONE_API_KEY = os.getenv("PINECONE_API_KEY")
PINECONE_INDEX_NAME = os.getenv("PINECONE_INDEX_NAME")
PINECONE_NAMESPACE = os.getenv("PINECONE_NAMESPACE", "kmu-rules_3")

# Embedding
EMBEDDING_MODEL_NAME = "BAAI/bge-m3"
EMBEDDING_MAX_SEQ_LENGTH = 512

# Retrieval
DEFAULT_TOP_K = 3
MAX_CONTEXT_CHARS_PER_CHUNK = 2500
MIN_RELEVANCE_SCORE = 0.50


# =========================
# 공통 유틸
# =========================

def check_env():
    missing = []

    if not GEMINI_API_KEY:
        missing.append("GEMINI_API_KEY")

    if not PINECONE_API_KEY:
        missing.append("PINECONE_API_KEY")

    if not PINECONE_INDEX_NAME:
        missing.append("PINECONE_INDEX_NAME")

    if missing:
        raise ValueError(f".env에 다음 값이 없습니다: {', '.join(missing)}")


def normalize_korean_input(text: str) -> str:
    """
    PyCharm/터미널 한글 입력 문제로
    '수 업 일 수'처럼 입력되는 경우를 방어.
    """
    text = str(text).strip()
    text = re.sub(r"(?<=[가-힣])\s+(?=[가-힣])", "", text)
    return text


def normalize_route_output(text: str) -> str:
    if not text:
        return "fail"

    result = text.strip().lower()
    result = result.replace("`", "")
    result = result.replace('"', "")
    result = result.replace("'", "")
    result = result.strip(" .,:;\n\t")

    if result in {"rag", "search", "fail"}:
        return result

    matches = re.findall(r"\b(rag|search|fail)\b", result)

    if len(matches) == 1:
        return matches[0]

    return "fail"


# =========================
# DuriTalk 통합 클래스
# =========================

class DuriTalk:
    def __init__(self):
        check_env()

        print("[INFO] Gemini client 초기화 중...")
        self.gemini_client = genai.Client(api_key=GEMINI_API_KEY)

        print(f"[INFO] Embedding model loading: {EMBEDDING_MODEL_NAME}")
        self.embedding_model = SentenceTransformer(EMBEDDING_MODEL_NAME)
        self.embedding_model.max_seq_length = EMBEDDING_MAX_SEQ_LENGTH

        print(f"[INFO] Pinecone index connecting: {PINECONE_INDEX_NAME}")
        pc = Pinecone(api_key=PINECONE_API_KEY)
        self.index = pc.Index(PINECONE_INDEX_NAME)

        print(f"[INFO] Router model: {ROUTER_MODEL}")
        print(f"[INFO] Answer model: {GEMINI_MODEL}")
        print(f"[INFO] Pinecone namespace: {PINECONE_NAMESPACE}")

    # =========================
    # 1. Router
    # =========================

    def classify_query(self, query: str) -> str:
        query = normalize_korean_input(query)

        if not query:
            return "fail"

        prompt = f"""
질문을 분류하라.

분류 기준:
rag = 국민대학교의 교칙, 학칙, 규정, 내규, 정관, 조항에 관한 질문
search = 국민대학교에 관련되어 있지만 학칙/교칙/규정과는 무관하거나 최신 웹 정보가 필요한 질문
fail = 국민대학교와 무관한 질문

예시:
수업일수는 몇 주 이상이어야 해? -> rag
휴학은 몇 학기까지 가능해? -> rag
징계 재심은 어떻게 청구해? -> rag
학점은 어떻게 인정돼? -> rag
졸업 요건은 뭐야? -> rag
국민대학교는 어디 있어? -> search
국민대 오늘 공지사항 알려줘 -> search
국민대 근처 카페 추천해줘 -> search
대한민국 대통령은 누구야? -> fail
오늘 점심 뭐 먹을까? -> fail
파이썬 리스트 정렬법 알려줘 -> fail

출력 규칙:
반드시 search, rag, fail 중 하나만 출력하라.
설명하지 마라.
마침표를 붙이지 마라.
JSON으로 출력하지 마라.
국민대학교라는 단어가 없어도, 질문이 학칙/규정에서 다루는 학사 제도 용어를 포함하면 rag로 분류하라.

질문:
{query}
""".strip()

        try:
            response = self.gemini_client.models.generate_content(
                model=ROUTER_MODEL,
                contents=prompt,
                config={
                    "temperature": 0.0,
                }
            )

            return normalize_route_output(response.text)

        except Exception as e:
            print("[Router Error]", repr(e))
            return "fail"

    # =========================
    # 2. RAG 검색
    # =========================

    def embed_query(self, query: str) -> List[float]:
        query = normalize_korean_input(query)

        vector = self.embedding_model.encode(
            query,
            normalize_embeddings=True
        )

        return vector.tolist()

    def retrieve_rule_chunks(self, query: str, top_k: int = DEFAULT_TOP_K) -> List[Dict[str, Any]]:
        query_vector = self.embed_query(query)

        result = self.index.query(
            vector=query_vector,
            top_k=top_k,
            include_metadata=True,
            namespace=PINECONE_NAMESPACE
        )

        contexts = []

        for match in result.get("matches", []):
            metadata = match.get("metadata", {})
            text = metadata.get("text", "")

            if len(text) > MAX_CONTEXT_CHARS_PER_CHUNK:
                text = text[:MAX_CONTEXT_CHARS_PER_CHUNK] + " ...[생략]"

            contexts.append({
                "id": match.get("id"),
                "score": match.get("score"),
                "part": metadata.get("part", ""),
                "rule_name": metadata.get("rule_name", ""),
                "chapter": metadata.get("chapter", ""),
                "article": metadata.get("article", ""),
                "text": text,
            })

        return contexts

    def format_source(self, ctx: Dict[str, Any]) -> str:
        parts = [
            ctx.get("part", ""),
            ctx.get("rule_name", ""),
            ctx.get("chapter", ""),
            ctx.get("article", ""),
        ]

        return " > ".join([p for p in parts if p])

    def build_context_text(self, contexts: List[Dict[str, Any]]) -> str:
        blocks = []

        for i, ctx in enumerate(contexts, start=1):
            source = self.format_source(ctx)

            block = f"""
[근거 {i}]
ID: {ctx["id"]}
유사도 점수: {ctx["score"]}
출처: {source}
내용:
{ctx["text"]}
""".strip()

            blocks.append(block)

        return "\n\n".join(blocks)

    def build_rag_prompt(self, query: str, contexts: List[Dict[str, Any]]) -> str:
        context_text = self.build_context_text(contexts)

        prompt = f"""
너는 국민대학교 교칙 및 규정 안내 assistant이다.

아래 [검색된 교칙 근거]만 사용해서 [사용자 질문]에 답변하라.

반드시 지켜야 할 규칙:
1. 검색된 근거에 있는 내용만 답변한다.
2. 근거에 없는 내용은 추측하지 않는다.
3. 답변 첫 문장에 결론을 짧게 말한다.
4. 답변에는 반드시 근거 규정의 출처를 포함한다.
5. 여러 규정이 관련되면 항목별로 정리한다.
6. 근거가 부족하면 "제공된 교칙 근거만으로는 확인할 수 없습니다."라고 말한다.
7. 사용자가 물은 내용이 학교 규정과 관련 없으면 "학교 규정과 관련된 질문이 아닙니다."라고 답한다.
8. 답변은 한국어로 작성한다.
9. 검색된 근거에 없는 일반상식, 정치, 시사, 인물 정보는 절대 답하지 않는다.
10. 근거 밖 지식을 사용해서 답변하면 안 된다.
11. 모델이 알고 있는 외부 지식은 모두 무시한다.
12. 검색 근거의 글자 사이 공백은 PDF 추출 오류일 수 있으므로, 최종 답변에서는 자연스러운 한국어 띄어쓰기로 정리한다.

[사용자 질문]
{query}

[검색된 교칙 근거]
{context_text}

[답변 형식]
결론:
...

근거:
- 규정명 > 장 > 조: ...

설명:
...
""".strip()

        return prompt

    def generate_with_gemini(self, prompt: str, temperature: float = 0.2) -> str:
        response = self.gemini_client.models.generate_content(
            model=GEMINI_MODEL,
            contents=prompt,
            config={
                "temperature": temperature,
            }
        )

        if not response.text:
            return "답변 생성에 실패했습니다."

        return response.text.strip()

    def answer_with_rag(self, query: str, top_k: int = DEFAULT_TOP_K) -> Dict[str, Any]:
        query = normalize_korean_input(query)
        contexts = self.retrieve_rule_chunks(query, top_k=top_k)

        if not contexts:
            return {
                "route": "rag",
                "query": query,
                "answer": "관련 교칙 근거를 찾지 못했습니다.",
                "contexts": [],
            }

        best_score = contexts[0]["score"]

        if best_score < MIN_RELEVANCE_SCORE:
            return {
                "route": "rag",
                "query": query,
                "answer": (
                    "제공된 교칙 데이터베이스에서는 해당 질문과 관련된 규정을 찾을 수 없습니다. "
                    "국민대학교 교칙, 학사, 행정 규정과 관련된 질문을 입력해 주세요."
                ),
                "contexts": contexts,
            }

        prompt = self.build_rag_prompt(query, contexts)
        answer = self.generate_with_gemini(prompt, temperature=0.2)

        return {
            "route": "rag",
            "query": query,
            "answer": answer,
            "contexts": contexts,
        }

    # =========================
    # 3. Search 계열 답변
    # =========================

    def answer_with_search_llm(self, query: str) -> Dict[str, Any]:
        query = normalize_korean_input(query)

        prompt = f"""
당신은 국민대학교 학생 도우미 'DuriTalk'입니다.
국민대학교는 서울특별시 성북구 정릉로 77에 위치해 있습니다.
주변 지하철역은 4호선 성신여대입구역, 우이신설선 정릉역이며,
정문 및 후문(북악터널 방면) 근처에 버스 정류장이 있어 버스 환승이 활발합니다.

### 규칙
1. 국민대학교 주변 환경(정릉, 길음, 혜화 인근 맛집/카페/상권 등) 및 학교 생활 팁에 대해 답변하세요.
2. 당신이 사전 학습을 통해 알고 있는 정보를 바탕으로 최대한 구체적으로 답변하세요.
3. 가게 이름, 대략적인 위치, 특징 등 구체적인 정보를 포함하세요.
4. 확실하지 않거나 최신 정보가 필요하다고 판단되는 경우(예: 폐업 가능성)에는 "이 정보는 변동이 있을 수 있으니 가시기 전에 지도 앱 등에서 영업 여부를 직접 확인해 보시는 것을 추천해요!"와 같은 안내 문구를 포함하세요.
5. 답변은 대학생에게 친근하고 다정한 말투로 작성하세요.

[질문]
{query}
""".strip()

        answer = self.generate_with_gemini(prompt, temperature=0.4)

        return {
            "route": "search",
            "query": query,
            "answer": answer,
            "contexts": [],
        }

    # =========================
    # 4. 전체 파이프라인
    # =========================

    def ask(self, query: str) -> Dict[str, Any]:
        query = normalize_korean_input(query)
        route = self.classify_query(query)

        if route == "rag":
            return self.answer_with_rag(query, top_k=DEFAULT_TOP_K)

        if route == "search":
            return self.answer_with_search_llm(query)

        return {
            "route": "fail",
            "query": query,
            "answer": "죄송합니다. 국민대학교 교칙, 학사, 학교 생활과 관련된 질문으로 다시 입력해 주세요.",
            "contexts": [],
        }


# =========================
# 출력 함수
# =========================

def print_answer(result: Dict[str, Any]):
    print("\n" + "=" * 80)
    print("[분류]")
    print(result.get("route"))

    #print("\n[질문]")
    #print(result.get("query"))

    print("\n[답변]")
    print(result.get("answer"))

    contexts = result.get("contexts", [])

    if contexts:
        print("\n[검색된 근거]")
        for i, ctx in enumerate(contexts, start=1):
            source_parts = [
                ctx.get("part", ""),
                ctx.get("rule_name", ""),
                ctx.get("chapter", ""),
                ctx.get("article", ""),
            ]

            source = " > ".join([x for x in source_parts if x])

            print("-" * 80)
            print(f"[근거 {i}]")
            print("id:", ctx.get("id"))
            print("score:", ctx.get("score"))
            print("source:", source)
            print("text:", ctx.get("text", "")[:300])


# =========================
# 실행부
# =========================

if __name__ == "__main__":
    print("=" * 80)
    print("DuriTalk All-in-One 실행 모드")
    print("종료하려면 q, quit, exit, 종료 중 하나를 입력하세요.")
    print("=" * 80)

    try:
        duritalk = DuriTalk()
        print("\n[초기화 완료]")

        while True:
            user_q = (input("\n질문: "))
            user_query = user_q.strip()

            if not user_query:
                continue

            if user_query.lower() in ["q", "quit", "exit", "종료"]:
                print("DuriTalk을 종료합니다.")
                break

            result = duritalk.ask(user_query)
            print_answer(result)

    except KeyboardInterrupt:
        print("\nDuriTalk을 종료합니다.")

    except Exception as e:
        print("\n[초기화 또는 실행 오류]")
        print(e)