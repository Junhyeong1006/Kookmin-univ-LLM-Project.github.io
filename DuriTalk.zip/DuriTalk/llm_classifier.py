import os
import re
from pathlib import Path
from dotenv import load_dotenv
from google import genai
from rule_rag_generate import RuleRAGGenerator, print_result
from search import search_with_llm


BASE_DIR = Path(__file__).resolve().parent
ENV_PATH = BASE_DIR / ".env"

load_dotenv(ENV_PATH)

gemini_api_key = os.getenv("GEMINI_API_KEY")

if not gemini_api_key:
    raise ValueError("GEMINI_API_KEY가 .env에 없습니다.")

ROUTER_MODEL = os.getenv("ROUTER_MODEL", "gemini-2.5-flash")

client = genai.Client(api_key=gemini_api_key)


def normalize_korean_input(text: str) -> str:
    text = str(text).strip()
    text = re.sub(r"(?<=[가-힣])\s+(?=[가-힣])", "", text)
    return text


def normalize_route_output(text: str) -> str:
    if not text:
        return "fail"

    result = text.strip().lower()
    result = result.replace("`", "")
    result = result.replace('"', "")
    result = result.replace("'", "")
    result = result.strip(" .,:;\n\t")

    if result in {"rag", "search", "fail"}:
        return result

    matches = re.findall(r"\b(rag|search|fail)\b", result)

    if len(matches) == 1:
        return matches[0]

    return "fail"


def classify_query(query: str) -> str:
    query = normalize_korean_input(query)

    if not query:
        return "fail"

    prompt = f"""
질문을 분류하라.

분류 기준:
rag = 국민대학교의 교칙, 학칙, 규정, 내규, 정관, 조항에 관한 질문
search = 국민대학교에 관련되어 있지만 학칙/교칙/규정과는 무관하거나 최신 웹 정보가 필요한 질문
fail = 국민대학교와 무관한 질문

예시:
수업일수는 몇 주 이상이어야 해? -> rag
휴학은 몇 학기까지 가능해? -> rag
징계 재심은 어떻게 청구해? -> rag
국민대학교는 어디 있어? -> search
국민대 오늘 공지사항 알려줘 -> search
대한민국 대통령은 누구야? -> fail
오늘 점심 뭐 먹을까? -> fail

출력 규칙:
반드시 search, rag, fail 중 하나만 출력하라.
설명하지 마라.
마침표를 붙이지 마라.
JSON으로 출력하지 마라.
국민대학교라는 단어가 없어도, 질문이 학칙/규정에서 다루는 학사 제도 용어를 포함하면 rag로 분류하라.

질문: {query}
""".strip()

    try:
        response = client.models.generate_content(
            model=ROUTER_MODEL,
            contents=prompt,
            config={
                "temperature": 0.0,
            }
        )

        return normalize_route_output(response.text)

    except Exception as e:
        print("[Router Error]", repr(e))
        return "fail"


if __name__ == "__main__":
    rag = RuleRAGGenerator()

    while True:
        q = input("\n질문을 입력하세요: ")
        if q == "q":
            break
        classified = classify_query(q)

        if classified == "rag":
            print("\n[RAG 답변]")
            result = rag.answer(q, top_k=3)
            print_result(result)

        elif classified == "search":
            answer = search_with_llm(q)
            print("\n[웹 검색 답변]")
            print(answer)

        else:
            print("국민대학교 관련 질문을 해주세요.")