llm_classifier.py: Router
search.py: 검색기
rule_rag_generate.py: RAG 바탕의 생성기

이 세 파일들은 서로 연결되어 있어 llm_classifier.py에서 질문을 입력하면 search.py 또는 rule_rag_generate.py를 통해 생성된 답변을 바로 받을 수 있습니다

즉, 실행은 llm_classifier.py만 하면 됨




Integrated.py: 통합본
위 3개의 파일들을 하나의 파이썬 파일로 묶은 것입니다. 실전에선 이걸 쓰면 될 듯?





아 그리고 .env파일이 필요한데 밑의 내용 채워서 복붙하면 됩니다 (제미나이 버전 바꿔도 되긴 하는데 그럼 코드도 바꿔야합니다):

PINECONE_API_KEY=(파인콘 API키)
PINECONE_INDEX_NAME=(파인콘 인덱스이름)
PINECONE_NAMESPACE=(파인콘 네임스페이스 이름)
GEMINI_API_KEY=(제미나이 API키)
GEMINI_MODEL=gemini-2.5-flash
ROUTER_MODEL=gemini-2.5-flash

파일 이름이 .env여야 합니다. 어쩌고저쩌고.env 이거 아니고 그냥 ".env" 이거 자체 딱 점하고 env만 잇어야됨
이미 아실것 같긴 한데 제가 이걸로 애먹었어서 써둡니다,,,