import os
import re
from pathlib import Path
from typing import List, Dict, Any, Optional

from dotenv import load_dotenv
from pinecone import Pinecone
from sentence_transformers import SentenceTransformer
from google import genai


BASE_DIR = Path(__file__).resolve().parent
ENV_PATH = BASE_DIR / ".env"

# Embedding
EMBEDDING_MODEL_NAME = "BAAI/bge-m3"
EMBEDDING_MAX_SEQ_LENGTH = 512

# Pinecone
DEFAULT_NAMESPACE = "kmu-rules_3"

# Retrieval
DEFAULT_TOP_K = 5
MAX_CONTEXT_CHARS_PER_CHUNK = 2500


class RuleRAGGenerator:
    def __init__(self):

        load_dotenv(ENV_PATH)

        gemini_api_key = os.getenv("GEMINI_API_KEY")
        self.gemini_model = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")

        if not gemini_api_key:
            raise ValueError("GEMINI_API_KEY가 .env에 없습니다.")

        self.gemini_client = genai.Client(api_key=gemini_api_key)

        print(f"[INFO] Gemini model: {self.gemini_model}")


        pinecone_api_key = os.getenv("PINECONE_API_KEY")
        index_name = os.getenv("PINECONE_INDEX_NAME")
        namespace = os.getenv("PINECONE_NAMESPACE", DEFAULT_NAMESPACE)

        if not pinecone_api_key:
            raise ValueError("PINECONE_API_KEY가 .env에 없습니다.")

        if not index_name:
            raise ValueError("PINECONE_INDEX_NAME이 .env에 없습니다.")

        self.namespace = namespace

        print(f"[INFO] Embedding model loading: {EMBEDDING_MODEL_NAME}")
        self.embedding_model = SentenceTransformer(EMBEDDING_MODEL_NAME)
        self.embedding_model.max_seq_length = EMBEDDING_MAX_SEQ_LENGTH

        print(f"[INFO] Pinecone index connecting: {index_name}")
        pc = Pinecone(api_key=pinecone_api_key)
        self.index = pc.Index(index_name)

    def embed_query(self, query: str) -> List[float]:
        if isinstance(query, tuple):
            query = query[0]

        if isinstance(query, list):
            query = query[0]

        query = str(query).strip()

        vector = self.embedding_model.encode(
            query,
            normalize_embeddings=True
        )

        return vector.tolist()

    def retrieve(self, query: str, top_k: int = DEFAULT_TOP_K) -> List[Dict[str, Any]]:
        query_vector = self.embed_query(query)

        result = self.index.query(
            vector=query_vector,
            top_k=top_k,
            include_metadata=True,
            namespace=self.namespace
        )

        contexts = []

        for match in result.get("matches", []):
            metadata = match.get("metadata", {})

            text = metadata.get("text", "")

            # prompt 너무 길어지는 것 방지
            if len(text) > MAX_CONTEXT_CHARS_PER_CHUNK:
                text = text[:MAX_CONTEXT_CHARS_PER_CHUNK] + " ...[생략]"

            contexts.append({
                "id": match.get("id"),
                "score": match.get("score"),
                "part": metadata.get("part", ""),
                "rule_name": metadata.get("rule_name", ""),
                "chapter": metadata.get("chapter", ""),
                "article": metadata.get("article", ""),
                "text": text,
            })

        return contexts

    def generate_with_gemini(self, prompt: str) -> str:
        response = self.gemini_client.models.generate_content(
            model=self.gemini_model,
            contents=prompt,
            config={
                "temperature": 0.2,
            }
        )

        if not response.text:
            return "답변 생성에 실패했습니다."

        return response.text.strip()

    def format_source(self, ctx: Dict[str, Any]) -> str:
        parts = [
            ctx.get("part", ""),
            ctx.get("rule_name", ""),
            ctx.get("chapter", ""),
            ctx.get("article", ""),
        ]

        return " > ".join([p for p in parts if p])

    def build_context_text(self, contexts: List[Dict[str, Any]]) -> str:
        blocks = []

        for i, ctx in enumerate(contexts, start=1):
            source = self.format_source(ctx)

            block = f"""
[근거 {i}]
ID: {ctx["id"]}
유사도 점수: {ctx["score"]}
출처: {source}
내용:
{ctx["text"]}
""".strip()

            blocks.append(block)

        return "\n\n".join(blocks)

    def build_prompt(self, query: str, contexts: List[Dict[str, Any]]) -> str:
        context_text = self.build_context_text(contexts)

        prompt = f"""
너는 국민대학교 교칙 및 규정 안내 assistant이다.

아래 [검색된 교칙 근거]만 사용해서 [사용자 질문]에 답변하라.

반드시 지켜야 할 규칙:
1. 검색된 근거에 있는 내용만 답변한다.
2. 근거에 없는 내용은 추측하지 않는다.
3. 답변 첫 문장에 결론을 짧게 말한다.
4. 답변에는 반드시 근거 규정의 출처를 포함한다.
5. 여러 규정이 관련되면 항목별로 정리한다.
6. 근거가 부족하면 "제공된 교칙 근거만으로는 확인할 수 없습니다."라고 말한다.
7. 사용자가 물은 내용이 학교 규정과 관련 없으면 "학교 규정과 관련된 질문이 아닙니다."라고 답한다.
8. 답변은 한국어로 작성한다.
9. 검색된 근거에 없는 일반상식, 정치, 시사, 인물 정보는 절대 답하지 않는다.
10. 사용자의 질문이 국민대학교 교칙과 관련 없으면 답변을 생성하지 말고 "교칙 관련 질문이 아닙니다."라고만 답한다.
11. 근거 밖 지식을 사용해서 답변하면 안 된다.
12. 모델이 알고 있는 외부 지식은 모두 무시한다.

[사용자 질문]
{query}

[검색된 교칙 근거]
{context_text}

[답변 형식]
결론:
...

근거:
- ...

설명:
...
""".strip()

        return prompt


    def answer(self, query: str, top_k: int = DEFAULT_TOP_K) -> Dict[str, Any]:
        contexts = self.retrieve(query, top_k=top_k)
        MIN_RELEVANCE_SCORE = 0.50

        if not contexts:
            return {
                "query": query,
                "answer": "관련 교칙 근거를 찾지 못했습니다.",
                "contexts": [],
                "prompt": None,
            }

        best_score = contexts[0]["score"]

        if best_score < MIN_RELEVANCE_SCORE:
            return {
                "query": query,
                "answer": "제공된 교칙 데이터베이스에서는 해당 질문과 관련된 규정을 찾을 수 없습니다. 국민대학교 교칙, 학사, 행정 규정과 관련된 질문을 입력해 주세요.",
                "contexts": contexts,
                "prompt": None,
            }

        prompt = self.build_prompt(query, contexts)
        answer = self.generate_with_gemini(prompt)

        return {
            "query": query,
            "answer": answer,
            "contexts": contexts,
            "prompt": prompt,
        }


def print_result(result: Dict[str, Any]):
    print("\n" + "=" * 80)
    print("[질문]")
    print(result["query"])

    print("\n" + "=" * 80)
    print("[답변]")
    print(result["answer"])

    print("\n" + "=" * 80)
    print("[검색된 근거]")
    for ctx in result["contexts"]:
        print("-" * 80)
        print("id:", ctx["id"])
        print("score:", ctx["score"])
        print("source:", " > ".join([
            x for x in [
                ctx["part"],
                ctx["rule_name"],
                ctx["chapter"],
                ctx["article"]
            ] if x
        ]))
        print("text:", ctx["text"][:300])

def normalize_korean_input(text: str) -> str:
    text = str(text)
    text = re.sub(r"(?<=[가-힣])\s+(?=[가-힣])", "", text)
    return text.strip()

if __name__ == "__main__":
    rag = RuleRAGGenerator()

    while True:
        raw_query = input("\n질문 입력, 종료하려면 q: ").strip()

        if raw_query.lower() == "q":
            break

        query = normalize_korean_input(raw_query)

        print("DEBUG raw_query type:", type(raw_query))
        print("DEBUG raw_query repr:", repr(raw_query))
        print("DEBUG query type:", type(query))
        print("DEBUG query repr:", repr(query))

        result = rag.answer(query, top_k=3)
        print_result(result)